<!DOCTYPE html>
<html>
<head>
	<title>Test-Grability</title>
</head>
<body>
 	<form action="/" method="post" accept-charset="UTF-8" enctype="multipart/form-data">
 		<?php echo e(csrf_field()); ?>

		<?php if($errors->any()): ?>
			<div style="background: red;width: 50%;border-radius: 5px">
				<p>Revise los siguientes errores:</p>
				<ul>
					<?php foreach($errors->all() as $error): ?>
						<li><?php echo e($error); ?></li>
					<?php endforeach; ?>
				</ul>
			</div>
		<?php endif; ?>
 		<h2>Por favor seleccione el archivo de entrada:</h2>
 		<label>Archivo:</label>
 		<input type="file" name="file_input" style="margin: 10px" required=""></input>	
		<button type="submit" style="display: block;margin: 10px">Calcular</button>
 	</form>
</body>
</html>