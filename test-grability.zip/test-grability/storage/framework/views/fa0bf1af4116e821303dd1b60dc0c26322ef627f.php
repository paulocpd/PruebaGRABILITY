<!DOCTYPE html>
<html>
<head>
	<title>Resultados - Test-Grability</title>
</head>
<body>
	<h2>Resultados:</h2>
	<ul>
		<?php foreach($output as $my_output): ?>
		<li><?php echo e($my_output); ?></li>
		<?php endforeach; ?>
	</ul>
	<a href="/">Regresar</a>
</body>
</html>