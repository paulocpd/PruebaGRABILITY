<!DOCTYPE html>
<html>
<head>
	<title>Test-Grability</title><link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.2/jquery.min.js"></script>
  <script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>
	<link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.2/jquery.min.js"></script>
  <script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>
</head>
<body>
<div class="container">
 	<form action="/" method="post" accept-charset="UTF-8" enctype="multipart/form-data">
 		<?php echo e(csrf_field()); ?>

		<?php if($errors->any()): ?>
			<div style="background: red;width: 50%;border-radius: 5px">
				<p>Revise los siguientes errores:</p>
				<ul>
					<?php foreach($errors->all() as $error): ?>
						<li><?php echo e($error); ?></li>
					<?php endforeach; ?>
				</ul>
			</div>
		<?php endif; ?>

 		<h2>Por favor seleccione el archivo de entrada:</h2>
 		<label>Archivo:</label>
 		<input type="file" class="btn btn-primary" name="file_input" style="margin: 10px" required=""></input>	
		<button type="submit" class="btn btn-primary" style="display: block;margin: 10px">Calcular</button>
 	</form>

</div>
</body>
</html>