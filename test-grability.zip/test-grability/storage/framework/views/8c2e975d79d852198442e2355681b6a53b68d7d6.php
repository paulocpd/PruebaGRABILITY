<!DOCTYPE html>
<html>
<head>
	<title>Resultados - Test-Grability</title>
		<title>Test-Grability</title>
	<link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.2/jquery.min.js"></script>
  <script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>
	<link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.2/jquery.min.js"></script>
  <script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>
</head>
<body>
<div class="container">
	<h2>Resultados:</h2>
	 <ul class="list-group">
		<?php foreach($output as $my_output): ?>
		<li class="list-group-item" ><?php echo e($my_output); ?></li>
		<?php endforeach; ?>
	</ul>
	<a href="/" class="btn btn-info">Regresar</a>
</body>
</div>
</html>